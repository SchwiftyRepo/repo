import xbmc
xbmc.executebuiltin("RunPlugin(plugin://plugin.video.vstream/?site=cFav&function=delBookmarkMenu)", True)
